
-- Ejecuta este SQL en Supabase > SQL Editor > New query.
-- Para un prototipo de clase. La política permite acceso público a la partida.
create table if not exists public.game_state (
    id bigint primary key,
    state jsonb not null
);

alter table public.game_state enable row level security;

drop policy if exists "public read game" on public.game_state;
drop policy if exists "public insert game" on public.game_state;
drop policy if exists "public update game" on public.game_state;

create policy "public read game"
on public.game_state for select
to anon, authenticated
using (true);

create policy "public insert game"
on public.game_state for insert
to anon, authenticated
with check (true);

create policy "public update game"
on public.game_state for update
to anon, authenticated
using (true)
with check (true);
