
import streamlit as st
import pandas as pd
import random
import json
import os
import requests
from datetime import datetime, timezone

st.set_page_config(
    page_title="VIRAL | The Brand Effect",
    page_icon="⚡",
    layout="wide"
)

st.markdown("""
<style>
.stApp {
 background:linear-gradient(135deg,#100D24,#21133D);
 color:#F8F7FF;
}
[data-testid="stSidebar"] {background:#211839}
h1 {color:#D7FF5F!important;font-weight:900!important}
h2,h3 {color:#C9B2FF!important}
[data-testid="stMetric"] {
 background:#2D2349;border:1px solid #7155A1;
 padding:14px;border-radius:15px
}
[data-testid="stMetricValue"] {color:#D7FF5F!important}
.stButton>button {
 background:linear-gradient(90deg,#A84DFF,#F44CB1);
 color:white;border:0;border-radius:10px;font-weight:800
}
</style>
""", unsafe_allow_html=True)

BRANDS = {
 "PULSE LAB":{"product":"PULSE Energy","cost":12,"price":30,"color":"#D7FF5F"},
 "CRUNCH UP":{"product":"CRUNCH Bites","cost":9,"price":22,"color":"#FF70C8"},
 "GLOW DISTRICT":{"product":"GLOW Mist","cost":18,"price":42,"color":"#B9A5FF"},
 "URBAN BEAT":{"product":"URBAN Caps","cost":22,"price":55,"color":"#7CCBFF"},
 "NOVA GEAR":{"product":"NOVA Buds","cost":35,"price":79,"color":"#FFA66B"}
}
SEGMENTS = {
 "Jóvenes trendsetters":{"size":25000,"sensitivity":0.85,"platform":"TikTok","need":"Tendencias, humor y retos"},
 "Profesionales activos":{"size":18000,"sensitivity":1.10,"platform":"Instagram","need":"Calidad, utilidad y estilo"},
 "Cazadores de ofertas":{"size":22000,"sensitivity":0.65,"platform":"Facebook","need":"Precio y promociones"},
 "Consumidores premium":{"size":10000,"sensitivity":1.40,"platform":"YouTube","need":"Diseño y exclusividad"}
}
PLATFORMS = {
 "TikTok":{"reach":1.35,"cost":1.0},
 "Instagram":{"reach":1.10,"cost":1.1},
 "Facebook":{"reach":0.85,"cost":0.75},
 "YouTube":{"reach":1.0,"cost":1.3}
}
INFLUENCERS = {
 "Sin influencer":{"fee":0,"followers":0,"engagement":0},
 "Vale Trend":{"fee":3000,"followers":20000,"engagement":.10},
 "Dani Risas":{"fee":6000,"followers":90000,"engagement":.075},
 "Mia Glow":{"fee":10000,"followers":160000,"engagement":.065},
 "TechNico":{"fee":8500,"followers":110000,"engagement":.06},
 "Max Impact":{"fee":22000,"followers":650000,"engagement":.035},
 "Luna Pro":{"fee":14000,"followers":220000,"engagement":.055}
}
EVENTS = [
 ("🚀 Lanzamiento viral","Los consumidores descubren nuevas marcas.","launch"),
 ("📱 Fiebre de videos cortos","Los retos y videos breves ganan fuerza.","short"),
 ("💸 Guerra de precios","Los consumidores comparan precios.","price"),
 ("🤝 Semana de cobranding","Las alianzas pueden ampliar el alcance.","cobrand"),
 ("⚠️ Crisis en redes","La reputación se pone a prueba.","crisis"),
 ("⭐ Calidad ante todo","Los consumidores valoran la calidad.","quality"),
 ("🔥 La estrella del momento","Los influencers grandes llaman la atención.","star"),
 ("📦 Demanda inesperada","Puede aumentar la demanda.","demand"),
 ("😴 Fatiga digital","Las campañas repetitivas pierden impacto.","fatigue"),
 ("🏆 La gran final","Última oportunidad de escalar posiciones.","final")
]

def initial_state():
    firms = {}
    for name, b in BRANDS.items():
        firms[name] = {
            "cash":100000.0, "price":float(b["price"]),
            "quality":65.0, "inventory":1200,
            "awareness":10.0, "reputation":60.0,
            "loyalty":10.0, "profit_total":0.0,
            "sales_total":0, "revenue_total":0.0,
            "history":[]
        }
    return {
        "round":1, "firms":firms, "decisions":{},
        "submitted":[], "resolved":False, "results":[],
        "log":["Partida creada."]
    }

# ----- Conexión opcional a Supabase para compartir la misma partida -----
# En Streamlit Cloud configura SUPABASE_URL y SUPABASE_KEY en Secrets.
URL = st.secrets.get("SUPABASE_URL", os.getenv("SUPABASE_URL","")).rstrip("/")
KEY = st.secrets.get("SUPABASE_KEY", os.getenv("SUPABASE_KEY",""))
SHARED = bool(URL and KEY)

def db_headers():
    return {
        "apikey":KEY,
        "Authorization":f"Bearer {KEY}",
        "Content-Type":"application/json",
        "Prefer":"return=representation"
    }

def load_shared():
    r=requests.get(
        URL+"/rest/v1/game_state?id=eq.1&select=state",
        headers=db_headers(),timeout=15
    )
    r.raise_for_status()
    rows=r.json()
    if not rows:
        state=initial_state()
        save_shared(state)
        return state
    return rows[0]["state"]

def save_shared(state):
    payload={"id":1,"state":state}
    r=requests.post(
        URL+"/rest/v1/game_state?on_conflict=id",
        headers={**db_headers(),"Prefer":"resolution=merge-duplicates,return=minimal"},
        json=payload,timeout=15
    )
    r.raise_for_status()

def get_state():
    if SHARED:
        try:
            return load_shared()
        except Exception as e:
            st.error("No se pudo leer Supabase. Revisa la tabla y las credenciales.")
            st.code(str(e))
            st.stop()
    if "local_game" not in st.session_state:
        st.session_state.local_game=initial_state()
    return st.session_state.local_game

def put_state(state):
    if SHARED:
        try:
            save_shared(state)
        except Exception as e:
            st.error("No se pudo guardar la partida compartida.")
            st.code(str(e))
            st.stop()
    else:
        st.session_state.local_game=state

def score(f):
    return (
        f["awareness"]*1.8 + f["reputation"]*.7
        + f["loyalty"]*.5 + f["profit_total"]/5000
        + f["sales_total"]/300
    )

st.title("⚡ VIRAL — THE BRAND EFFECT")
st.caption("MARKETING DIGITAL · ESTRATEGIA · COMPETENCIA")
state=get_state()
rnd=state["round"]
firms=state["firms"]
event_name,event_desc,event_type=EVENTS[rnd-1]

with st.sidebar:
    st.title("🎮 Centro de control")
    st.write(f"Ronda: **{rnd}/10**")
    st.write("🌐 Partida compartida" if SHARED else "🧪 Modo de prueba local")
    if st.button("🔄 Actualizar pantalla"):
        st.rerun()
    if st.button("🧹 Reiniciar campeonato"):
        if st.session_state.get("confirm_reset",False):
            put_state(initial_state())
            st.session_state.confirm_reset=False
            st.rerun()
        else:
            st.session_state.confirm_reset=True
            st.warning("Pulsa de nuevo para confirmar el reinicio.")
    if st.button("📣 Cerrar mercado y calcular", disabled=state["resolved"]):
        if len(state["submitted"]) < len(BRANDS):
            st.warning("Faltan equipos por registrar sus decisiones.")
        else:
            resolve=True
            plans=state["decisions"]
            potentials={}
            rng=random.Random(7300+rnd)
            for n,p in plans.items():
                f=firms[n]; b=BRANDS[n]
                seg=SEGMENTS[p["segment"]]
                plat=PLATFORMS[p["platform"]]
                inf=INFLUENCERS[p["influencer"]]
                ratio=p["price"]/b["price"]
                price_factor=max(.35,min(1.45,seg["sensitivity"]**(ratio-1)))
                fit=1.2 if seg["platform"]==p["platform"] else .82
                qfactor=.60+p["quality"]/150
                creative=.65+p["creativity"]/180
                viral=(p["ad_budget"]/1000*400+inf["followers"]*inf["engagement"]*2.5)*plat["reach"]*creative
                event_factor=1.0
                if event_type=="short" and p["content"]=="Reto viral": event_factor=1.35
                if event_type=="price": event_factor=1.20 if p["price"]<=b["price"] else .75
                if event_type=="cobrand" and p["cobrand"]: event_factor=1.35
                if event_type=="quality": event_factor=1.20 if p["quality"]>=75 else .90
                if event_type=="star" and inf["followers"]>=150000: event_factor=1.25
                if event_type=="fatigue" and p["creativity"]<40: event_factor=.70
                appeal=.012+f["awareness"]/2000+viral/180000
                demand=seg["size"]*appeal*price_factor*fit*qfactor*event_factor*(.70+f["reputation"]/200)*rng.uniform(.90,1.10)
                if p["objective"]=="Ventas": demand*=1.10
                if p["objective"]=="Viralidad": demand*=1.05
                if p["cobrand"]: demand*=1.08
                potentials[n]=max(0,demand)
                p["_viral"]=viral
            total=sum(potentials.values())
            market=min(total,24000 if event_type=="demand" else 18000)
            results=[]
            for n,p in plans.items():
                f=firms[n]; b=BRANDS[n]
                requested=int(market*potentials[n]/max(1,total))
                available=f["inventory"]+p["production"]
                sold=min(requested,available)
                revenue=sold*p["price"]
                campaign=p["ad_budget"]+p["influencer_cost"]+p["alliance_cost"]+p["quality_cost"]
                profit=revenue-p["production_cost"]-campaign
                f["cash"]+=profit
                f["profit_total"]+=profit
                f["sales_total"]+=sold
                f["revenue_total"]+=revenue
                f["inventory"]=max(0,available-sold)
                f["price"]=p["price"]; f["quality"]=p["quality"]
                f["awareness"]=max(0,min(100,f["awareness"]+min(15,p["_viral"]/4500)+sold/2500))
                rep_change=(p["quality"]-60)/20
                if event_type=="crisis" and p["objective"]!="Reputación": rep_change-=2
                f["reputation"]=max(0,min(100,f["reputation"]+rep_change))
                f["loyalty"]=max(0,min(100,f["loyalty"]+(2 if p["objective"]=="Fidelización" else 0)+(p["quality"]-60)/25))
                row={
                    "Empresa":n,"Unidades vendidas":sold,"Precio (Bs)":p["price"],
                    "Ingresos (Bs)":round(revenue),"Costos (Bs)":round(p["production_cost"]+campaign),
                    "Beneficio (Bs)":round(profit),"Caja (Bs)":round(f["cash"]),
                    "Inventario":f["inventory"],"Notoriedad":round(f["awareness"],1),
                    "Reputación":round(f["reputation"],1),"Puntuación":round(score(f),2)
                }
                f["history"].append(row); results.append(row)
            state["results"]=results
            state["resolved"]=True
            state["log"].append(f"Ronda {rnd} calculada.")
            put_state(state)
            st.rerun()

st.progress(rnd/10,text=f"RONDA {rnd} DE 10")
st.info(f"**{event_name}** — {event_desc}")

st.header("🔎 Radar de mercado")
a,b,c,d=st.columns(4)
a.metric("Mercado potencial",f"{sum(x['size'] for x in SEGMENTS.values()):,}")
b.metric("Segmentos",len(SEGMENTS))
c.metric("Plataformas",len(PLATFORMS))
d.metric("Influencers",len(INFLUENCERS)-1)
with st.expander("👥 Segmentos de consumidores",expanded=True):
    st.dataframe(pd.DataFrame([
        {"Segmento":n,"Mercado estimado":v["size"],"Sensibilidad al precio":v["sensitivity"],"Red preferida":v["platform"],"Intereses":v["need"]}
        for n,v in SEGMENTS.items()
    ]),hide_index=True,use_container_width=True)
with st.expander("📱 Plataformas digitales"):
    st.dataframe(pd.DataFrame([{"Plataforma":n,"Alcance relativo":v["reach"],"Costo relativo":v["cost"]} for n,v in PLATFORMS.items()]),hide_index=True,use_container_width=True)
with st.expander("🌟 Influencers"):
    st.dataframe(pd.DataFrame([{"Nombre":n,"Seguidores":v["followers"],"Interacción":f"{v['engagement']*100:.1f}%","Tarifa (Bs)":v["fee"]} for n,v in INFLUENCERS.items()]),hide_index=True,use_container_width=True)

st.header("🏢 Competencia")
st.dataframe(pd.DataFrame([
    {"Empresa":n,"Producto":BRANDS[n]["product"],"Precio":f["price"],"Notoriedad":round(f["awareness"],1),"Reputación":round(f["reputation"],1),"Inventario":f["inventory"],"Caja (Bs)":round(f["cash"])}
    for n,f in firms.items()
]),hide_index=True,use_container_width=True)

team=st.selectbox("Selecciona la empresa de tu equipo",list(BRANDS))
f=firms[team]; brand=BRANDS[team]
m=st.columns(5)
m[0].metric("Caja",f"Bs {f['cash']:,.0f}")
m[1].metric("Notoriedad",f"{f['awareness']:.1f}/100")
m[2].metric("Reputación",f"{f['reputation']:.1f}/100")
m[3].metric("Fidelidad",f"{f['loyalty']:.1f}/100")
m[4].metric("Inventario",f"{f['inventory']:,}")

st.header("🎯 Decisiones del equipo")
st.caption("Solo elige opciones; no necesitas redactar estrategias.")
if state["resolved"]:
    st.warning("La ronda está cerrada.")
elif team in state["submitted"]:
    st.success("Decisión registrada. Espera a los demás equipos.")
else:
    with st.form("decision_form"):
        price=st.slider("Precio por unidad (Bs)",max(5,int(brand["cost"])),int(brand["cost"]*3.5),int(f["price"]))
        production=st.select_slider("Producción nueva",options=[0,100,200,300,400,500,600,800,1000,1200,1500,1800,2000],value=500)
        quality=st.slider("Calidad",40,100,int(f["quality"]))
        segment=st.selectbox("Público objetivo",list(SEGMENTS))
        platform=st.selectbox("Red principal",list(PLATFORMS))
        objective=st.selectbox("Objetivo",["Viralidad","Ventas","Reputación","Fidelización"])
        influencer=st.selectbox("Influencer",list(INFLUENCERS),format_func=lambda x:f"{x} — Bs {INFLUENCERS[x]['fee']:,}")
        creativity=st.slider("Creatividad",0,100,65)
        content=st.selectbox("Contenido",["Reto viral","Humor","Demostración","Historia emocional","Oferta y descuento","Tutorial","Testimonio"])
        cobrand=st.checkbox("Proponer alianza de cobranding (Bs 3.000)")
        ad_budget=st.slider("Publicidad (Bs)",0,min(30000,max(0,int(f["cash"]))),min(5000,max(0,int(f["cash"]))),step=500)
        submit=st.form_submit_button("🔒 Registrar decisión")
    if submit:
        inf=INFLUENCERS[influencer]
        production_cost=production*brand["cost"]
        quality_cost=max(0,quality-f["quality"])*production*.10
        alliance_cost=3000 if cobrand else 0
        total=production_cost+quality_cost+inf["fee"]+ad_budget+alliance_cost
        if total>f["cash"]:
            st.error(f"Presupuesto insuficiente. Costo estimado Bs {total:,.0f}; caja Bs {f['cash']:,.0f}.")
        else:
            state["decisions"][team]={
                "price":price,"production":production,"quality":quality,
                "segment":segment,"platform":platform,"objective":objective,
                "influencer":influencer,"creativity":creativity,"content":content,
                "cobrand":cobrand,"ad_budget":ad_budget,
                "production_cost":production_cost,"quality_cost":quality_cost,
                "influencer_cost":inf["fee"],"alliance_cost":alliance_cost
            }
            state["submitted"].append(team)
            put_state(state)
            st.success("Decisión registrada.")
            st.rerun()

st.divider()
st.header("🏁 Resultados")
st.write(f"Decisiones registradas: **{len(state['submitted'])}/{len(BRANDS)}**")
if state["resolved"]:
    df=pd.DataFrame(state["results"])
    st.dataframe(df,hide_index=True,use_container_width=True)
    ranking=df.sort_values("Puntuación",ascending=False).reset_index(drop=True)
    ranking.insert(0,"Posición",range(1,len(ranking)+1))
    st.subheader("🏆 Ranking de la ronda")
    st.dataframe(ranking,hide_index=True,use_container_width=True)
    st.bar_chart(ranking.set_index("Empresa")[["Unidades vendidas"]])
    if rnd<10:
        if st.button("➡️ Avanzar ronda"):
            state["round"]+=1
            state["decisions"]={}
            state["submitted"]=[]
            state["resolved"]=False
            state["results"]=[]
            state["log"].append(f"Inicio de ronda {state['round']}.")
            put_state(state)
            st.rerun()
    else:
        st.balloons()
        final=[]
        for n,f in firms.items():
            final.append({
                "Empresa":n,"Puntuación final":round(score(f),2),
                "Beneficio acumulado (Bs)":round(f["profit_total"]),
                "Ingresos acumulados (Bs)":round(f["revenue_total"]),
                "Unidades vendidas":f["sales_total"],
                "Notoriedad":round(f["awareness"],1),
                "Reputación":round(f["reputation"],1)
            })
        final=sorted(final,key=lambda x:x["Puntuación final"],reverse=True)
        st.title(f"🥇 CAMPEÓN: {final[0]['Empresa']}")
        st.dataframe(pd.DataFrame(final),hide_index=True,use_container_width=True)
        st.download_button("⬇️ Descargar resultados",pd.DataFrame(final).to_csv(index=False).encode("utf-8"),"viral_resultados.csv","text/csv")
else:
    st.info("El facilitador calcula la ronda cuando todos hayan registrado sus decisiones.")

with st.expander("📈 Historial"):
    if f["history"]:
        st.dataframe(pd.DataFrame(f["history"]),hide_index=True,use_container_width=True)
    else:
        st.write("Aún no hay resultados.")
