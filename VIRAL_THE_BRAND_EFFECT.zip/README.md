# VIRAL — THE BRAND EFFECT

## Archivos
- viral_app.py: aplicación Streamlit
- requirements.txt: dependencias
- supabase_setup.sql: tabla para partida compartida

## Publicación
1. Sube estos archivos a un repositorio GitHub.
2. Ejecuta supabase_setup.sql en Supabase SQL Editor.
3. En Streamlit Community Cloud, crea una app usando viral_app.py.
4. En Advanced settings > Secrets, configura:
   SUPABASE_URL = "https://TU_PROYECTO.supabase.co"
   SUPABASE_KEY = "TU_CLAVE_PUBLICA_ANON"
5. Guarda y espera el despliegue.

Si no configuras Supabase, la aplicación funciona en modo local,
pero las sesiones de los jugadores no compartirán la misma partida.

IMPORTANTE: la tabla y las políticas de ejemplo permiten a cualquier visitante
leer y modificar la partida. Úsalas solo para un prototipo educativo sin datos
personales ni información sensible. Para uso evaluado, añade autenticación,
roles de facilitador y controles de permisos.
